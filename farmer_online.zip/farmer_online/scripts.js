// Select all 'Add to Cart' buttons
const addToCartButtons = document.querySelectorAll('.add-to-cart');

// Cart items array to store added items
let cartItems = [];

// Add event listeners to 'Add to Cart' buttons
addToCartButtons.forEach(button => {
    button.addEventListener('click', () => {
        const product = button.parentElement;
        const productId = product.dataset.id;
        const productName = product.dataset.name;
        const productPrice = parseFloat(product.dataset.price);

        // Check if the item is already in the cart
        const existingItem = cartItems.find(item => item.id === productId);

        if (existingItem) {
            existingItem.quantity++;
        } else {
            cartItems.push({ id: productId, name: productName, price: productPrice, quantity: 1 });
        }

        displayCartItems();
    });
});

// Function to display cart items
function displayCartItems() {
    const cartContainer = document.querySelector('.cart-items');
    cartContainer.innerHTML = '';

    cartItems.forEach(item => {
        const cartItem = document.createElement('div');
        cartItem.classList.add('cart-item');
        cartItem.innerHTML = `
      <p>${item.name} - Quantity: ${item.quantity}</p>
      <p>Total: $${item.price * item.quantity}</p>
    `;
        cartContainer.appendChild(cartItem);
    });

    updateTotalPrice();
}

// Function to update total price
function updateTotalPrice() {
    const totalPrice = cartItems.reduce((total, item) => total + (item.price * item.quantity), 0);
    document.getElementById('total-price').textContent = `Total Price: $${totalPrice}`;
}

// Generate bill button
const generateBillButton = document.querySelector('.generate-bill');
generateBillButton.addEventListener('click', () => {
    // You can implement bill generation logic here
    const billFrame = document.getElementById('bill-frame');
    const billContent = generateBillContent();

    // Update iframe content with bill details
    billFrame.contentDocument.body.innerHTML = billContent;
    //   alert('Bill generated! Check console for details.');
    //   console.log(cartItems);
});

// Function to generate bill content
function generateBillContent() {
    let billContent = '<h2>Generated Bill</h2>';
    if (cartItems.length === 0) {
        billContent += '<p>Your cart is empty. Add items before generating a bill.</p>';
    } else {
        billContent += '<table>';
        billContent += '<tr><th>Product</th><th>Quantity</th><th>Total Price</th></tr>';

        cartItems.forEach(item => {
            billContent += `<tr><td>${item.name}</td><td>${item.quantity}</td><td>$${item.price * item.quantity}</td></tr>`;
        });

        billContent += '</table>';
        billContent += `<p>Total Price: $${cartItems.reduce((total, item) => total + (item.price * item.quantity), 0)}</p>`;
    }
    return billContent;
}

