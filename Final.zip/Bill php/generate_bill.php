<?php
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $u = $_POST["units"];
    $name = $_POST["name"];
    $month = $_POST["month"];
    $id = $_POST["userid"];

    if ($u > 0 && $u <= 100) {
        $ans = $u * 3.36;
    } else if ($u > 100 && $u <= 300) {
        $ans = $u * 7.34;
    } else if ($u > 300 && $u <= 500) {
        $ans = $u * 10.37;
    } else if ($u > 500 && $u <= 1000) {
        $ans = $u * 11.86;
    } else {
        $ans = $u * 11.86;
    }

    echo '<div style="font-family: Arial, sans-serif; text-align: center;">';
    echo "<h1>Electricity Bill Generator</h1>";
    echo "<p><b>User Id: $id</b></p>";
    echo "<p><b>Name: $name</b></p>";
    echo "<p><b>Month: $month</b></p>";
    echo "<p><b>Units Consumed: $u</br></p>";
    echo "<p><b>Total Bill: ₹$ans</b></p>";
    echo '</div>';
}
?>

