CREATE TABLE `results` (
  `RollNo` int(10) UNSIGNED PRIMARY KEY NOT NULL AUTO_INCREMENT,
  `OS` varchar(255) NOT NULL,
  `CN` varchar(255) NOT NULL,
  `CS` varchar(255) NOT NULL,
  `AI` varchar(255) NOT NULL,
  `CGPA` varchar(255) NOT NULL
);
