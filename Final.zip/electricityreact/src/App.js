import logo from "./logo.svg";
import { useState } from 'react';
import "./App.css";

function App() {
  const [name, setName] = useState("");
  const [units, setUnits] = useState("");
  const [customerType, setCustomerType] = useState("residential");
  const [result, setResult] = useState("");
  const [showResult, setShowResult] = useState(false);

  const calculateBill = () => {
    if (!/^\d+$/.test(units) || units <= 0) {
      setResult("Please enter a valid number of units.");
      setShowResult(false);
      return;
    }
    const rate = customerType === "residential" ? 5 : 7;
    const billAmount = units * rate;
    setResult(`₹${billAmount}`); // Using ₹ for Rupee symbol
    setShowResult(true);
  };

  return (
    <div className="App">
      <h1>Electricity Bill Calculator</h1>
      <form>
        <label>
          Your Name:
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
        </label>
        <label>
          Enter Units Consumed:
          <input
            type="number"
            value={units}
            onChange={(e) => setUnits(e.target.value)}
            required
          />
        </label>
        <label>
          Select Customer Type:
          <select
            value={customerType}
            onChange={(e) => setCustomerType(e.target.value)}
          >
            <option value="residential">Residential</option>
            <option value="commercial">Commercial</option>
          </select>
        </label>
        <button type="button" onClick={calculateBill}>
          Calculate Bill
        </button>
      </form>
      {showResult && (
        <div id="result">
          <p>{name}</p>
          <p>Your Electricity Bill is: {result}</p>
        </div>
      )}
    </div>
  );
}

export default App;
