// npm init
//npm i express mysql cors

import express from "express";
import mysql from "mysql";
import cors from "cors";

const app = express();
const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "CDTprathamesh",
  database: "test",
});

app.use(express.json());
app.use(cors());

app.get("/books", (req, res) => {
  const q = "SELECT * FROM crudnode";
  db.query(q, (err, data) => {
    if (err) return res.json(err);
    return res.json(data);
  });
});

app.post("/books", (req, res) => {
  const { title, description, cover } = req.body; // Destructure values from req.body

  if (!title || !description || !cover) {
    return res.status(400).json({ error: "Please provide all book details" });
  }

  const q =
    "INSERT INTO crudnode (`title`,`description`, `cover`) VALUES (?, ?, ?)";
  const values = [title, description, cover];

  db.query(q, values, (err, data) => {
    if (err) return res.json(err);
    return res.json("Book has been created");
  });
});

app.delete("/books/:id", (req, res) => {
    const bookId = req.params.id;
    const q = "DELETE FROM books WHERE id= ?"
    db.query(q, bookId, (err, data) => {
        if (err) return res.json(err);
        return res.json("Book has been deleted");
      });
});
app.listen(8800, () => {
  console.log("Connected to backend! ");
});